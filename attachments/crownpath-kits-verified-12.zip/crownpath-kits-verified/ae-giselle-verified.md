# ae-GISELLE

Short: ae-GISELLE

Element: Earth

Class: Mage

Rarity: 5

Tier: niche

Base Speed: 103

Patch / date used: 2026-09-06 in-game Journal (screenshots)

## Roles

dps, buffer, single-target

## Tags

single-target, cr-push, increase-attack, cr-amplify, dispel, soulburn, ignore-damage-share, extra-turn

## Effects

current-hp-ratio-damage, cr-increase-amplify, ignore-damage-sharing, debuff-dispel

## Buffs

Increase Attack

## Debuffs

none

## Unique effects

### Linguistic Wisdom

Self-only. Amplifies the effect of Combat Readiness increases the caster receives by 50%. At the start of the turn, has a 70% chance to dispel one debuff (skill enhances +5%×4 +10% → 100% fully enhanced).

### Increase Attack

Caster + ally. Increases Attack by 50%. Granted by Frame of Light for 2 turns to the caster and the ally with the highest Attack except for the caster.

### Damage Sharing (ignored)

Receives a portion of the damage suffered by targets in their place. When more than one damage sharing effect of the same kind is granted, only the strongest effect is applied. Frame of Light ignores damage share when the enemy is not an Elite or Boss monster.

### Extra Turn

Grants an extra turn. Frame of Light: when the enemy is defeated, grants an extra turn.

## Kit

S1 Surging Light (+1 Soul): Attacks the enemy, and increases Combat Readiness of the ally with the highest Attack except for the caster by **10%** (enhancements +2% / +3% CR → **15%** fully enhanced). Damage dealt increases proportional to the target's current Health ratio. Soulburn (consume 10 Soul): Increases damage dealt.

S2 Linguistic Wisdom (passive): Amplifies the effect of Combat Readiness increases the caster receives by 50%. At the start of the turn, has a **70%** chance to dispel one debuff (→ **100%** fully enhanced).

S3 Frame of Light (+3 Souls, 5-turn cooldown, enhance −1 → 4): Attacks the enemy with light, before granting increased Attack to the caster and the ally with the highest Attack except for the caster for 2 turns. When the enemy is not an Elite or Boss monster, ignores damage share. When the enemy is defeated, grants an extra turn.

Memory Imprint: Release Attack % (B–SSS +5%→+15%). Concentration Attack % (B–SSS +7%→+21%).

Preview Stats (6★ awaken Lv.60): Atk 1286 / Def 652 / HP 4733 / Speed **103** / Crit 27% / CDMG 160% / Eff 0% / ER 0% / Dual 3%.

## Defense / offense

3 / 7

## Unsure

- Exact S1 damage coefficient vs target current Health ratio
- First-fight opening CD of Frame of Light vs listed skill CD

## Object

```ts
{
  id: "ae-giselle",
  name: "ae-GISELLE",
  short: "ae-GISELLE",
  element: "earth",
  class: "mage",
  tier: "niche",
  rarity: 5,
  roles: ["dps", "buffer", "single-target"],
  tags: ["single-target", "cr-push", "increase-attack", "cr-amplify", "dispel", "soulburn", "ignore-damage-share", "extra-turn"],
  effects: ["current-hp-ratio-damage", "cr-increase-amplify", "ignore-damage-sharing", "debuff-dispel"],
  buffs: ["Increase Attack"],
  debuffs: [],
  uniqueEffects: [
    {
      name: "Linguistic Wisdom",
      scope: "self-only",
      tooltip: "Amplifies CR increases the caster receives by 50%. Start of turn: 70% (→100% FE) dispel one debuff."
    },
    {
      name: "Increase Attack",
      scope: "team-wide",
      tooltip: "Increases Attack by 50%. Frame of Light: caster + highest-Atk ally except caster for 2 turns."
    },
    {
      name: "Extra Turn",
      scope: "self-only",
      tooltip: "When the enemy is defeated by Frame of Light, grants an extra turn."
    }
  ],
  kit: "S1 Surging Light (+1 Soul): CR push highest-Atk ally 10%→15% FE; dmg ∝ target current HP ratio; Soulburn (−10) more dmg. S2 Linguistic Wisdom: +50% CR amplify received; SoT dispel 1 debuff 70%→100% FE. S3 Frame of Light (+3 Souls, 5→4 CD): Increase Attack (+50%) self+ally 2t; ignore damage share vs non-Elite/Boss; kill → extra turn.",
  defense: 3,
  offense: 7,
  baseSpeed: 103,
  verified: true
}
```
