# Adventurer Ras

Short: ARas

Element: Fire

Class: Knight

Rarity: 3

Tier: niche

Base Speed: 95

Patch / date used: 2026-09-06 in-game Journal (screenshots)

## Roles

tank, strip, cleave, healer

## Tags

dual-attack, strip, soulburn, defup

## Effects

buff-dispel, dual-attack

## Buffs

Increase Defense

## Debuffs

none (base Journal skills; Decrease Defense only via specialty Speed Rune — not shown in these screenshots)

## Unique effects

### Dual Attack

Ally basic. When an ally attacks with a basic skill, if the caster is able to act, attacks the same target with a basic attack. Cannot be triggered by counterattacks. Triggered by Command Strike from the ally with the highest Attack.

### Increase Defense

Team-wide. Increases Defense by 60%. Granted by Purifying Flame for 2 turns.

### Specialty Change Runes (not shown on these Journal skill screenshots)

Prior research (2025-02-13 era) — **not verified** in this pass. Includes Solitude / Wedge / Speed / Order / Sun / Fruition and other runes. Needs Specialty Skill Tree screenshots to lock.

## Kit

S1 X-Slash (+1 Soul): Attacks with a sword, with 75% chance to dispel a buff. Damage dealt increases proportional to the caster's max Health.

S2 Command Strike (+2 Souls, 3-turn cooldown): Attacks the enemy repeatedly, before triggering a Dual Attack from the ally with the highest Attack. Soulburn (consume 10 Soul): Skill cooldown is decreased by 2 turns.

S3 Purifying Flame (+2 Souls, 4-turn cooldown): Strongly attacks all enemies with a swordstorm, before recovering Health of the caster, and increases Defense of all allies for 2 turns. Amount recovered and damage dealt increase proportional to the caster's max Health. Increase Defense = +60%.

Memory Imprint: Release flat Health (D–S shown: +150→+450; SS/SSS not in screenshot). Concentration flat Health (D–S shown: +230→+690; SS/SSS not in screenshot).

Preview Stats (6★ awaken Lv.60): Atk 758 / Def 672 / HP 5826 / Speed **95** / Crit 15% / CDMG 150% / Eff 0% / ER 12% / Dual 3%.

## Defense / offense

8 / 3

## Unsure

- Specialty Change rune tooltips (Solitude, Wedge, Speed Def-break, Order/Sun CR, Fruition, etc.) — not in these screenshots
- Imprint SS/SSS flat Health values (scrolled off)
- First-fight opening CD vs listed skill CD

## Object

```ts
{
  id: "adventurer-ras",
  name: "Adventurer Ras",
  short: "ARas",
  element: "fire",
  class: "knight",
  tier: "niche",
  rarity: 3,
  roles: ["tank", "strip", "cleave", "healer"],
  tags: ["dual-attack", "strip", "soulburn", "defup"],
  effects: ["buff-dispel", "dual-attack"],
  buffs: ["Increase Defense"],
  debuffs: [],
  uniqueEffects: [
    {
      name: "Dual Attack",
      scope: "team-wide",
      tooltip: "When an ally attacks with a basic skill, if the caster is able to act, attacks the same target with a basic attack. Cannot be triggered by counterattacks."
    },
    {
      name: "Increase Defense",
      scope: "team-wide",
      tooltip: "Increases Defense by 60%. Granted by Purifying Flame for 2 turns."
    }
  ],
  kit: "S1 X-Slash (+1 Soul): 75% dispel 1 buff; dmg ∝ max HP. S2 Command Strike (+2 Souls, 3 CD): repeated attack then Dual Attack from highest-Atk ally; Soulburn (−10) CD −2. S3 Purifying Flame (+2 Souls, 4 CD): AoE; self heal; Increase Defense (+60%) all allies 2 turns; heal/dmg ∝ max HP. Specialty runes: not verified this pass.",
  defense: 8,
  offense: 3,
  baseSpeed: 95,
  verified: true
}
```
