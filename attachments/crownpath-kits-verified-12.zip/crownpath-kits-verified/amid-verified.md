# Amid

Short: Amid

Element: Ice

Class: Soul Weaver

Rarity: 5

Tier: niche

Base Speed: 117

Patch / date used: 2026-09-06 in-game Journal (screenshots)

## Roles

cr-push, skill-nullifier, cleanse, enabler, opener

## Tags

single-target, aoe-cr, skill-nullifier, extra-turn, swift-attack, cleanse, soulburn, increase-attack

## Effects

increase-cr, skill-nullifier, extra-turn, swift-attack-end-of-turn-cr, debuff-dispel

## Buffs

Skill Nullifier, Swift Attack, Increase Attack

## Debuffs

none

## Unique effects

### Skill Nullifier

Allies. Nullifies damage from skills. Granted once to all allies by Forest Blessing.

### Extra Turn

Self. Grants an extra turn. Granted by Forest Blessing.

### Swift Attack

Ally. At the end of the turn, increases Combat Readiness by 50%. Dispelled when the effect is activated. Granted by Touch of Hope.

### Increase Attack

Ally. Increases Attack by 50%. Granted by Touch of Hope for 2 turns.

## Kit

S1 Zephyr (+1 Soul): Attacks the enemy with a fan, and increases Combat Readiness of the caster by **10%** (enhancements +2% / +3% → **15%** fully enhanced). Soulburn (consume 10 Soul): Combat Readiness increase effect will be applied to all allies.

S2 Forest Blessing (+2 Souls, 5-turn cooldown, enhance −1 → 4): Grants skill nullifier once to all allies and increases Combat Readiness by **15%** (enhancements +1/+1/+1/+2/+2/+3% → **25%** fully enhanced). Grants an extra turn.

S3 Touch of Hope (+2 Souls, 5-turn cooldown, enhance −1 → 4): With Elven magic, dispels two debuffs from an ally except for the caster and grants Swift Attack. Increases Attack of the target for 2 turns.

Memory Imprint: Release Attack % (B–SSS +4%→+12%). Concentration Effect Resistance (B–SSS +9%→+27%).

Preview Stats (6★ awaken Lv.60): Atk 694 / Def 655 / HP 4855 / Speed **117** / Crit 15% / CDMG 150% / Eff 0% / ER 30% / Dual 3%.

## Defense / offense

3 / 2

## Unsure

- First-fight opening CD of Forest Blessing / Touch of Hope
- Whether Touch of Hope has additional enhance lines beyond −1 CD (only +1 shown in screenshot)

## Object

```ts
{
  id: "amid",
  name: "Amid",
  short: "Amid",
  element: "ice",
  class: "soul weaver",
  tier: "niche",
  rarity: 5,
  roles: ["cr-push", "skill-nullifier", "cleanse", "enabler", "opener"],
  tags: ["single-target", "aoe-cr", "skill-nullifier", "extra-turn", "swift-attack", "cleanse", "soulburn", "increase-attack"],
  effects: ["increase-cr", "skill-nullifier", "extra-turn", "swift-attack-end-of-turn-cr", "debuff-dispel"],
  buffs: ["Skill Nullifier", "Swift Attack", "Increase Attack"],
  debuffs: [],
  uniqueEffects: [
    {
      name: "Swift Attack",
      scope: "team-wide",
      tooltip: "At the end of the turn, increases Combat Readiness by 50%. Dispelled when the effect is activated."
    },
    {
      name: "Skill Nullifier",
      scope: "team-wide",
      tooltip: "Nullifies damage from skills. Forest Blessing: once to all allies."
    },
    {
      name: "Increase Attack",
      scope: "team-wide",
      tooltip: "Increases Attack by 50%. Touch of Hope: target ally for 2 turns."
    }
  ],
  kit: "S1 Zephyr (+1 Soul): caster CR +10%→15% FE; Soulburn (−10) CR to all allies. S2 Forest Blessing (+2 Souls, 5→4 CD): skill nullifier all allies + CR +15%→25% FE + Extra Turn. S3 Touch of Hope (+2 Souls, 5→4 CD): cleanse 2 debuffs (ally except caster) + Swift Attack + Increase Attack (+50%) 2 turns.",
  defense: 3,
  offense: 2,
  baseSpeed: 117,
  verified: true
}
```
