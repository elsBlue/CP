# Afternoon Soak Flan

Short: ASFlan

Element: Fire

Class: Ranger

Rarity: 5

Tier: niche

Base Speed: 114

Patch / date used: 2026-09-06 in-game Journal (screenshots)

## Roles

dps, control, cleave

## Tags

stun, dual-attack, evade, always-crit, defbreak, soulburn, cr-push, aoe, focus

## Effects

dual-attack, increase-cr, increase-evasion, always-crit, ignore-er

## Buffs

none

## Debuffs

Stun, Decrease Defense

## Unique effects

### Focus

Self-only. At the start of the first battle, gains 3 Focus. It's a Whopper! gains 1 Focus. When an ally uses a basic skill, consumes 1 Focus to Dual Attack (if Focus ≥ 1).

### It's a Whopper!

Self-only (replaces Do Not Disturb on caster's turn). Attacks all enemies and gains 1 Focus. A successful attack always results in a critical hit. Does not trigger a Dual Attack or counterattack.

### I'm Still On Vacation! evasion

Self-only. Increases Evasion by 50%, and when Focus is 1 or higher, increases Evasion by an additional 50%.

### Stun

Enemy. Cannot act for a certain number of turns.

### Decrease Defense

Enemy. Decreases Defense by 70%.

### Dual Attack

When an ally attacks with a basic skill, if the caster is able to act, attacks the same target with a basic attack. Cannot be triggered by counterattacks.

## Kit

S1 Do Not Disturb (+1 Soul): Attacks the enemy with a gun, with a **30%** chance to stun for 1 turn (enhance +10% effect chance → **40%** fully enhanced). A successful attack always results in a critical hit. When used on the caster's turn, becomes **It's a Whopper!** instead (AoE, +1 Focus, always crit, no Dual Attack or counterattack).

S2 I'm Still On Vacation! (passive): At the start of the first battle, gains 3 Focus. Increases Evasion by 50%, and if Focus is 1 or higher, increases Evasion by an additional 50%. When an ally uses a basic skill, consumes 1 Focus to trigger a Dual Attack and increases the caster's Combat Readiness by **15%** (enhancements +10% total → **25%** fully enhanced).

S3 In the Palm of My Hand (+3 Souls, 5-turn cooldown, enhance −1 → 4): Attacks the enemy, decreasing Defense for 2 turns, and increases Combat Readiness of **all allies** by 20%. A successful attack always results in a critical hit. Soulburn (consume 10 Soul): Ignores Effect Resistance.

Memory Imprint: Release Health % (B–SSS +5%→+15%). Concentration Attack % (B–SSS +7%→+21%).

Preview Stats (6★ awaken Lv.60): Atk 1182 / Def 571 / HP 5299 / Speed **114** / Crit 15% / CDMG 150% / Eff 18% / ER 0% / Dual 3%.

## Defense / offense

4 / 8

## Unsure

- First-fight opening CD of In the Palm of My Hand
- Exact Stealth-style wording N/A; Focus max capacity beyond start-3 / gains (assume standard Focus rules)

## Object

```ts
{
  id: "afternoon-soak-flan",
  name: "Afternoon Soak Flan",
  short: "ASFlan",
  element: "fire",
  class: "ranger",
  tier: "niche",
  rarity: 5,
  roles: ["dps", "control", "cleave"],
  tags: ["stun", "dual-attack", "evade", "always-crit", "defbreak", "soulburn", "cr-push", "aoe", "focus"],
  effects: ["dual-attack", "increase-cr", "increase-evasion", "always-crit", "ignore-er"],
  buffs: [],
  debuffs: ["Stun", "Decrease Defense"],
  uniqueEffects: [
    {
      name: "Focus",
      scope: "self-only",
      tooltip: "Starts first battle with 3 Focus. It's a Whopper! +1 Focus. Ally basic skill: spend 1 Focus to Dual Attack."
    },
    {
      name: "It's a Whopper!",
      scope: "self-only",
      tooltip: "On own turn S1: AoE always-crit, +1 Focus; no Dual Attack or counterattack."
    },
    {
      name: "I'm Still On Vacation! evasion",
      scope: "self-only",
      tooltip: "+50% Evasion; +50% more when Focus ≥ 1."
    }
  ],
  kit: "S1 Do Not Disturb / It's a Whopper! (+1 Soul): off-form Stun 30%→40% FE + always crit; own turn AoE always-crit +1 Focus, no Dual/counter. S2 passive: 3 Focus first battle; Eva 50%/100% with Focus; ally basic spends 1 Focus → Dual Attack + caster CR 15%→25% FE. S3 In the Palm of My Hand (+3 Souls, 5→4 CD): Def-break 2 turns (−70%); all-allies CR +20%; always crit; Soulburn (−10) ignore ER.",
  defense: 4,
  offense: 8,
  baseSpeed: 114,
  verified: true
}
```
