# ae-WINTER

Short: ae-WIN

Element: Fire

Class: Thief

Rarity: 5

Tier: niche

Base Speed: 118

Patch / date used: 2026-09-06 in-game Journal (screenshots)

## Roles

opener, control, dps, cleanse

## Tags

stun, soulburn, fixed-dmg, immunity, stealth, cr-push

## Effects

debuff-dispel, increase-cr, skill-cooldown-reset

## Buffs

Stealth, Immunity

## Debuffs

Stun

## Unique effects

### Stun

Enemy. Cannot act for a certain number of turns.

### Stealth

Self. When another ally is present, prevents enemies from selecting the bearer as a skill target. When suffering an attack that targets all allies, grants damage reduction and is dispelled when suffering damage from an attack. Granted by Next Level at battle start and end of turn for 1 turn.

### Immunity

Self. Cannot be affected by any debuffs or some harmful effects. Granted by Level Up for 2 turns.

### Level Up

Self-only. Grants Immunity to the caster for 2 turns and resets cooldown of Black Out.

### Black Out additional damage

Self-only on S3. A critical hit will inflict 5,000 additional damage. Increases additional damage by 5,000 every time this skill is used, up to 20,000.

## Kit

S1 Rapid Cut (+1 Soul): Attacks the enemy with a sword and has a **30%** chance to stun for 1 turn (enhancements +5% / +5% effect chance → **40%** fully enhanced). Soulburn (consume 10 Soul): Increases effect chance to 100%.

S2 Next Level (passive, 3-turn cooldown, enhance −1 → 2): At the start of battle and at the end of the turn, grants stealth for 1 turn. After an enemy uses a non-attack skill, dispels all debuffs from the caster and activates Level Up (Immunity 2 turns + reset Black Out cooldown).

S3 Black Out (+3 Souls, 6-turn cooldown, enhance −1 → 5): Attacks the enemy with various weapons, inflicts stun for 2 turns, and increases Combat Readiness of the caster by 50%. A critical hit will inflict 5,000 additional damage. Increases additional damage by 5,000 every time this skill is used, up to 20,000.

Memory Imprint: Release Attack % (B–SSS +4.8%→+14.4%). Concentration Critical Hit Chance (B–SSS +6%→+18%).

Preview Stats (6★ awaken Lv.60): Atk 1057 / Def 532 / HP 5542 / Speed **118** / Crit 15% / CDMG 150% / Eff 30% / ER 0% / Dual 3%.

## Defense / offense

5 / 6

## Unsure

- First-fight opening CD of Black Out / Next Level ICD vs listed skill CD
- Exact Stealth AoE damage-reduction %

## Object

```ts
{
  id: "ae-winter",
  name: "ae-WINTER",
  short: "ae-WIN",
  element: "fire",
  class: "thief",
  tier: "niche",
  rarity: 5,
  roles: ["opener", "control", "dps", "cleanse"],
  tags: ["stun", "soulburn", "fixed-dmg", "immunity", "stealth", "cr-push"],
  effects: ["debuff-dispel", "increase-cr", "skill-cooldown-reset"],
  buffs: ["Stealth", "Immunity"],
  debuffs: ["Stun"],
  uniqueEffects: [
    {
      name: "Level Up",
      scope: "self-only",
      tooltip: "Grants Immunity to the caster for 2 turns and resets cooldown of Black Out."
    },
    {
      name: "Next Level",
      scope: "self-only",
      tooltip: "Battle start + end of turn: Stealth 1 turn. After enemy non-attack skill: full cleanse self + Level Up (ICD = skill CD 3→2)."
    },
    {
      name: "Black Out additional damage",
      scope: "self-only",
      tooltip: "On crit: 5,000 additional damage. +5,000 each use of this skill, up to 20,000."
    },
    {
      name: "Stealth",
      scope: "self-only",
      tooltip: "When another ally is present, prevents single-target selection. AoE: damage reduction; dispelled when taking attack damage."
    }
  ],
  kit: "S1 Rapid Cut (+1 Soul): Stun 30%→40% FE; Soulburn (−10) 100%. S2 Next Level (passive, 3→2 CD): Stealth start/EOT; enemy non-attack → cleanse + Level Up (Immunity 2t + Black Out CD reset). S3 Black Out (+3 Souls, 6→5 CD): Stun 2 turns; CR +50%; crit add-dmg 5k→20k max.",
  defense: 5,
  offense: 6,
  baseSpeed: 118,
  verified: true
}
```
