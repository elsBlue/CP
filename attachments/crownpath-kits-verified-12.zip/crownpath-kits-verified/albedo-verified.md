# Albedo

Short: Albedo

Element: Earth

Class: Knight

Rarity: 5

Tier: niche

Base Speed: 104

Patch / date used: 2026-09-06 in-game Journal (screenshots)

## Roles

tank, counter, defense-break, bruiser

## Tags

hp-scaling, counter, aoe, strip, decrease-defense, unbuffable, increase-speed, damage-reduction, soulburn

## Effects

max-hp-scaled-damage, ally-crit-damage-reduction, counter-bicorn, buff-dispel

## Buffs

Increase Speed

## Debuffs

Unable to be Buffed, Decrease Defense

## Unique effects

### Aegis Unfold

Allies / self. When an ally suffers a critical hit, grants **15%** damage reduction (enhancements −0.5/−0.5/−1/−1/−2% damage received → **20%** fully enhanced). When an ally except for the caster suffers a critical hit, counterattacks with Let's Go, Bicorn!. When more than one damage reduction effect of the same kind is granted, only the strongest effect is applied. Counter ICD if any: **UNSURE** (not shown on these Journal screenshots).

### Let's Go, Bicorn!

AoE. Attacks all enemies, dispelling one buff, before granting increased Speed to the caster for 2 turns (+30%). Damage dealt increases proportional to the caster's max Health.

### Unable to be Buffed / Cannot Buff

Enemy. The target cannot receive any buffs.

### Decrease Defense

Enemy. Decreases Defense by 70%.

### Increase Speed

Self. Increases Speed by 30%.

## Kit

S1 No Need for Words (+1 Soul): Attacks the enemy with a bardiche, before dealing additional damage. Increases Combat Readiness of the caster by **15%** (enhancements +2% / +3% → **20%** fully enhanced). Damage dealt and additional damage increase proportional to the caster's max Health.

S2 Aegis Unfold (passive): See unique effects.

S3 Rage of Nazarick (+3 Souls, 5-turn cooldown, enhance −1 → 4): Fiercely attacks the wicked enemy, with a **75%** chance each to dispel all buffs from the target, make them unable to be buffed, and decrease Defense for 2 turns (enhancements +10% / +15% effect chance → **100%** fully enhanced). Damage dealt increases proportional to the caster's max Health. Soulburn (consume 10 Soul): Skill cooldown is decreased by 2 turns.

Memory Imprint: Release Effect Resistance % (B–SSS +5%→+15%). Concentration Health % (B–SSS +7%→+21%).

Preview Stats (6★ awaken Lv.60): Atk 894 / Def 694 / HP 6840 / Speed **104** / Crit 15% / CDMG 150% / Eff 0% / ER 0% / Dual 3%.

## Defense / offense

8 / 5

## Unsure

- Whether Let's Go, Bicorn! has a separate internal cooldown (not listed on Journal passive text)
- Exact S1 additional-damage and Bicorn damage coefficients vs max Health
- First-fight opening CD of Rage of Nazarick

## Object

```ts
{
  id: "albedo",
  name: "Albedo",
  short: "Albedo",
  element: "earth",
  class: "knight",
  tier: "niche",
  rarity: 5,
  roles: ["tank", "counter", "defense-break", "bruiser"],
  tags: ["hp-scaling", "counter", "aoe", "strip", "decrease-defense", "unbuffable", "increase-speed", "damage-reduction", "soulburn"],
  effects: ["max-hp-scaled-damage", "ally-crit-damage-reduction", "counter-bicorn", "buff-dispel"],
  buffs: ["Increase Speed"],
  debuffs: ["Unable to be Buffed", "Decrease Defense"],
  uniqueEffects: [
    {
      name: "Aegis Unfold",
      scope: "team-wide",
      tooltip: "On ally crit: 15%→20% FE damage reduction. On ally-except-self crit: Let's Go, Bicorn! (AoE strip 1 + Speed Up self 2 turns). Bicorn ICD: UNSURE."
    },
    {
      name: "Let's Go, Bicorn!",
      scope: "self-only",
      tooltip: "AoE attack; dispel one buff; Increase Speed (+30%) caster 2 turns; dmg ∝ max HP."
    }
  ],
  kit: "S1 No Need for Words (+1 Soul): CR +15%→20% FE; dmg + add-dmg ∝ max HP. S2 Aegis Unfold: ally crit → DR 15%→20% FE; ally-except-self crit → Bicorn AoE strip1 + Speed Up. S3 Rage of Nazarick (+3 Souls, 5→4 CD): 75%→100% FE each full strip + Unbuffable + Def-break 2 turns; Soulburn (−10) CD −2.",
  defense: 8,
  offense: 5,
  baseSpeed: 104,
  verified: true
}
```
