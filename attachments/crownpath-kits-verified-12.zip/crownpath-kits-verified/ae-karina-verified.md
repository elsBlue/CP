# ae-KARINA

Short: ae-KARINA

Element: Ice

Class: Knight

Rarity: 5

Tier: niche

Base Speed: 110

Patch / date used: 2026-09-06 in-game Journal (screenshots)

## Roles

bruiser, defense-break, barrier, tank

## Tags

single-target, aoe-splash, decrease-defense, defense-scaling, barrier, cr-push, soulburn, increase-defense, increase-speed

## Effects

defense-scaled-damage, ally-low-hp-trigger, leave-it-to-me-barrier, additional-aoe-damage

## Buffs

Increase Defense, Barrier, Increase Speed

## Debuffs

Decrease Defense

## Unique effects

### Leave It To Me!

Self + allies. Triggered by Rocket Punch: grants increased Defense to the caster for 2 turns (+60%), and grants a barrier (proportional to the caster's Defense) to all allies for 2 turns.

### Decrease Defense

Enemy. Decreases Defense by 70%.

### Increase Defense

Self. Increases Defense by 60%.

### Increase Speed

Self. Increases Speed by 30%. Granted by I'll Blow You Away! for 2 turns.

### Barrier

Allies. When suffering damage, absorbs a certain amount of damage instead of Health. Strength ∝ caster Defense (exact coefficient: UNSURE).

## Kit

S1 Exposed! (+1 Soul): Attacks the enemy by punching them, with a **65%** chance to decrease Defense for 1 turn (enhance +10% effect chance → **75%** fully enhanced). Damage dealt increases proportional to the caster's Defense. Soulburn (consume 10 Soul): Increases effect chance to 100%, and decreases Defense of the target for **2 turns**.

S2 Rocket Punch (passive, 3-turn cooldown): When Health of an ally except for the caster is 50% or less after being attacked, increases Combat Readiness of the caster by **35%** (enhancements +2/+3/+3/+3/+4% → **50%** fully enhanced) and activates Leave It To Me! (Increase Defense caster 2 turns + Barrier all allies 2 turns ∝ Defense).

S3 I'll Blow You Away! (+3 Souls, 4-turn cooldown, enhance −1 → 3): Attacks the enemy by slamming them with a fist, inflicting decreased Defense for 2 turns, before granting increased Speed to the caster for 2 turns. Deals additional damage to all enemies. Damage dealt and additional damage increase proportional to the caster's Defense.

Memory Imprint: Release Health % (B–SSS +4%→+12%). Concentration Defense % (B–SSS +7%→+21%).

Preview Stats (6★ awaken Lv.60): Atk 821 / Def 648 / HP 6751 / Speed **110** / Crit 15% / CDMG 150% / Eff 18% / ER 0% / Dual 3%.

## Defense / offense

7 / 6

## Unsure

- Exact additional AoE damage coefficient on S3
- Exact Barrier strength coefficient vs Defense
- First-fight opening CD of I'll Blow You Away! / Rocket Punch ICD display

## Object

```ts
{
  id: "ae-karina",
  name: "ae-KARINA",
  short: "ae-KARINA",
  element: "ice",
  class: "knight",
  tier: "niche",
  rarity: 5,
  roles: ["bruiser", "defense-break", "barrier", "tank"],
  tags: ["single-target", "aoe-splash", "decrease-defense", "defense-scaling", "barrier", "cr-push", "soulburn", "increase-defense", "increase-speed"],
  effects: ["defense-scaled-damage", "ally-low-hp-trigger", "leave-it-to-me-barrier", "additional-aoe-damage"],
  buffs: ["Increase Defense", "Barrier", "Increase Speed"],
  debuffs: ["Decrease Defense"],
  uniqueEffects: [
    {
      name: "Leave It To Me!",
      scope: "team-wide",
      tooltip: "Increase Defense caster 2 turns (+60%); Barrier all allies 2 turns ∝ caster Defense."
    },
    {
      name: "Decrease Defense",
      scope: "self-only",
      tooltip: "Decreases Defense by 70%."
    },
    {
      name: "Increase Speed",
      scope: "self-only",
      tooltip: "Increases Speed by 30%. Granted by I'll Blow You Away! for 2 turns."
    }
  ],
  kit: "S1 Exposed! (+1 Soul): Def-break 65%→75% FE for 1 turn; dmg ∝ Def; Soulburn (−10) 100% Def-break 2 turns. S2 Rocket Punch (passive, 3 CD): ally ≤50% HP after attack → CR +35%→50% FE + Leave It To Me! (Def Up self + Barrier allies). S3 I'll Blow You Away! (+3 Souls, 4→3 CD): Def-break 2 turns + Speed Up self 2 turns (+30%) + add-dmg all enemies; scales with Defense.",
  defense: 7,
  offense: 6,
  baseSpeed: 110,
  verified: true
}
```
