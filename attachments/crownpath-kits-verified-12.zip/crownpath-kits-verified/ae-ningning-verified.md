# ae-NINGNING

Short: ae-NING

Element: Fire

Class: Soul Weaver

Rarity: 5

Tier: niche

Base Speed: 114

Patch / date used: 2026-09-06 in-game Journal (screenshots)

## Roles

strip, control, opener

## Tags

stun, strip, soulburn, cr-push, cr-cut, barrier-inversion

## Effects

decrease-cr, increase-cr, buff-dispel, barrier-inversion

## Buffs

Increase Attack

## Debuffs

Stun

## Unique effects

### Stun

Enemy. Cannot act for a certain number of turns.

### Increase Attack

Ally. Increases Attack by 50%. Granted by Butterfly Effect for 2 turns to the ally with the highest Attack except for the caster.

### Barrier Inversion

Enemies (Heroes only). Inverts barrier into damage. Unaffected by Effect Resistance and whether the attack hits, and applies to Heroes only.

### Barrier

When suffering damage, absorbs a certain amount of damage instead of Health. Relevant to System Hacking CR double condition.

## Kit

S1 SSAMBEAR (+1 Soul): Attacks the enemy with SSAMBEAR, with a **30%** chance to stun for 1 turn (enhance +10% effect chance → **40%** fully enhanced). After attacking, when the target is stunned, increases Combat Readiness of the caster by 20%. Soulburn (consume 10 Soul): Increases effect chance to 100%.

S2 Butterfly Effect (+1 Soul, 3-turn cooldown, enhance −1 → 2): Attacks the enemy, decreasing Combat Readiness by 30%. Increases Attack of the ally with the highest Attack except for the caster for 2 turns and increases Combat Readiness by 30%.

S3 System Hacking (+3 Souls, 5-turn cooldown, enhance −1 → 4): Hacks all enemies, inflicting barrier inversion and dispelling two buffs, before increasing Combat Readiness of the caster by **40%** (enhancements +2/+2/+3/+3% → **50%** fully enhanced). When the target is granted a barrier, Combat Readiness increase amount is doubled.

Memory Imprint: Release Attack % (B–SSS +4%→+12%). Concentration Effectiveness (B–SSS +9%→+27%).

Preview Stats (6★ awaken Lv.60): Atk 785 / Def 634 / HP 5077 / Speed **114** / Crit 15% / CDMG 150% / Eff 30% / ER 0% / Dual 3%.

## Defense / offense

4 / 3

## Unsure

- First-fight opening CD of Butterfly Effect / System Hacking vs listed skill CD
- Whether System Hacking is treated as a non-attack skill for counter/passives (Journal: “Hacks all enemies”)

## Object

```ts
{
  id: "ae-ningning",
  name: "ae-NINGNING",
  short: "ae-NING",
  element: "fire",
  class: "soul weaver",
  tier: "niche",
  rarity: 5,
  roles: ["strip", "control", "opener"],
  tags: ["stun", "strip", "soulburn", "cr-push", "cr-cut", "barrier-inversion"],
  effects: ["decrease-cr", "increase-cr", "buff-dispel", "barrier-inversion"],
  buffs: ["Increase Attack"],
  debuffs: ["Stun"],
  uniqueEffects: [
    {
      name: "Barrier Inversion",
      scope: "team-wide",
      tooltip: "Inverts barrier into damage. Unaffected by Effect Resistance and whether the attack hits, and applies to Heroes only."
    },
    {
      name: "Increase Attack",
      scope: "team-wide",
      tooltip: "Increases Attack by 50%. Butterfly Effect: highest-Atk ally except caster for 2 turns."
    },
    {
      name: "System Hacking CR",
      scope: "self-only",
      tooltip: "Caster CR +40% (→50% FE). When the target is granted a barrier, CR increase is doubled."
    }
  ],
  kit: "S1 SSAMBEAR (+1 Soul): Stun 30%→40% FE; on stun caster CR +20%; Soulburn (−10) Stun 100%. S2 Butterfly Effect (+1 Soul, 3→2 CD): enemy CR −30%; highest-Atk ally (except caster) Increase Attack (+50%) 2 turns + CR +30%. S3 System Hacking (+3 Souls, 5→4 CD): AoE barrier inversion + dispel 2; caster CR +40%→50% FE, doubled if target has barrier.",
  defense: 4,
  offense: 3,
  baseSpeed: 114,
  verified: true
}
```
