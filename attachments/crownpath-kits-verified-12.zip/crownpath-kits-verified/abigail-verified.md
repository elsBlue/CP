# Abigail

Short: Abi

Element: Fire

Class: Warrior

Rarity: 5

Tier: niche

Base Speed: 117

Patch / date used: 2026-09-06 in-game Journal (screenshots)

## Roles

bruiser, strip, saver, cleanse

## Tags

injury, strip, soulburn, cr-push, immortality, vampirism, curse

## Effects

increase-cr, buff-dispel, debuff-dispel, injury

## Buffs

Immortality, Vampirism

## Debuffs

Curse

## Unique effects

### Might

Team-wide. Increases Combat Readiness of all allies by 15%. Activated from Ambush as an extra effect.

### Injury

Target (Heroes only). Cumulatively decreases max Health proportional to damage suffered, up to 50%. Unaffected by Effect Resistance or whether or not the attack hits. Scarlet Garden inflicts up to 25% injuries per use.

### Curse

Enemy. When an ally except for the bearer is attacked, deals additional damage equivalent to 60% of damage dealt to the bearer.

### Immortality

Ally. Cannot die for a certain number of turns. Granted by Blood Banquet for 1 turn.

### Vampirism

Ally. When attacking, absorbs 30% of damage dealt as Health. Granted by Blood Banquet for 1 turn.

## Kit

S1 Ambush (+1 Soul): Attacks the enemy with bloodied wings, and increases Combat Readiness of the caster by 15%. When used on the caster's turn, has a 35% chance to activate Might as an extra effect. Damage dealt increases proportional to the caster's max Health. Soulburn (consume 10 Soul): Increases chance of activating Might to 100%. Might is an extra effect (not Dual Attack / Extra Attack).

S2 Blood Banquet (passive, 5-turn cooldown, skill enhance +1 → 4): At the start of the turn, inflicts curse on the enemy with the highest Attack for 1 turn. When the ally in the back row except for the caster receives lethal damage, consumes 30% of the caster's current Health, dispelling all debuffs from the target before granting immortality and vampirism for 1 turn.

S3 Scarlet Garden (+3 Souls, 5-turn cooldown, enhance −1 → 4): After dispelling all buffs from the target, attacks the enemy with a field of bloody thorns, inflicting up to 25% injuries. Increases Effectiveness by 50% when using this skill, and damage dealt increases proportional to the caster's max Health.

Memory Imprint: Release Effect Resistance (B–SSS +6%→+18%, allies in positions, not caster). Concentration Critical Hit Chance (B–SSS +6%→+18%, caster).

## Defense / offense

7 / 5

## Unsure

- Base Speed 117 not shown on these Journal skill screenshots (kept from prior DB)
- First-fight (opening) cooldown display vs listed skill CD

## Object

```ts
{
  id: "abigail",
  name: "Abigail",
  short: "Abi",
  element: "fire",
  class: "warrior",
  tier: "niche",
  rarity: 5,
  roles: ["bruiser", "strip", "saver", "cleanse"],
  tags: ["injury", "strip", "soulburn", "cr-push", "immortality", "vampirism", "curse"],
  effects: ["increase-cr", "buff-dispel", "debuff-dispel", "injury"],
  buffs: ["Immortality", "Vampirism"],
  debuffs: ["Curse"],
  uniqueEffects: [
    {
      name: "Might",
      scope: "team-wide",
      tooltip: "Increases Combat Readiness of all allies by 15%."
    },
    {
      name: "Injury",
      scope: "self-only",
      tooltip: "Cumulatively decreases max Health proportional to damage suffered, up to 50%. Applies to Heroes only. Unaffected by Effect Resistance or whether or not the attack hits. Scarlet Garden: up to 25% injuries per use."
    },
    {
      name: "Curse",
      scope: "self-only",
      tooltip: "When an ally except for the bearer is attacked, deals additional damage equivalent to 60% of damage dealt to the bearer."
    },
    {
      name: "Vampirism",
      scope: "team-wide",
      tooltip: "When attacking, absorbs 30% of damage dealt as Health."
    }
  ],
  kit: "S1 Ambush (+1 Soul): CR +15% self; 35% Might on own turn (team CR +15%); dmg ∝ max HP; Soulburn (−10) Might 100%. S2 Blood Banquet (passive, 5→4 CD): SoT Curse highest-Atk enemy 1 turn; back-row ally lethal → spend 30% current HP, full cleanse target, Immortality + Vampirism 1 turn. S3 Scarlet Garden (+3 Souls, 5→4 CD): full strip then attack, up to 25% injuries; +50% Effectiveness; dmg ∝ max HP.",
  defense: 7,
  offense: 5,
  baseSpeed: 117,
  verified: true
}
```
