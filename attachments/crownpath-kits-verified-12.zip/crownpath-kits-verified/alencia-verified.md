# Alencia

Short: Alencia

Element: Earth

Class: Warrior

Rarity: 5

Tier: niche

Base Speed: 106

Patch / date used: 2026-09-06 in-game Journal (screenshots)

## Roles

bruiser, defense-break, strip, injury

## Tags

hp-scaling, decrease-defense, injury, extra-attack, strip, aoe, increase-defense, cr-push, soulburn, mind-eye

## Effects

max-hp-scaled-damage, trample-extra-attack, injuries-on-attack, buff-dispel, ignore-er

## Buffs

Mind's Eye, Increase Defense

## Debuffs

Decrease Defense, Injury

## Unique effects

### Mind's Eye

Self-only (undispellable). At the start of the turn, **75%** chance to grant Mind's Eye for 1 turn (enhancements +10% / +15% → **100%** fully enhanced). While granted Mind's Eye, inflicts up to **10%** injuries when attacking. Enables Trample after Eradicate.

### Trample

Extra skill (single). After using Eradicate, if the caster is granted Mind's Eye, activates Trample: Attacks the enemy by striking from above and increases Combat Readiness of the caster by 15%. Damage dealt increases proportional to the caster's max Health.

### Decrease Defense

Enemy. Decreases Defense by 70%.

### Increase Defense

Allies. Increases Defense by 60%. Granted by Genesis for 2 turns.

### Injury

Target (Heroes). Cumulatively decreases max Health proportional to damage suffered (standard Injury rules); Mind's Eye attacks inflict up to 10% injuries.

## Kit

S1 Eradicate (+1 Soul): Attacks the enemy by battering them, with a **60%** chance to decrease Defense for 1 turn (enhancements +5% / +10% effect chance → **75%** fully enhanced). Damage dealt increases proportional to the caster's max Health. Soulburn (consume 10 Soul): Increases effect chance to 100% and ignores Effect Resistance.

S2 Noble Blood (passive): Increases Critical Hit Chance by 20%. At the start of the turn, has a 75% chance (→100% FE) to grant Mind's Eye for 1 turn. After using Eradicate, if Mind's Eye is granted, activates Trample as an extra skill.

S3 Genesis (+3 Souls, 5-turn cooldown, enhance −1 → 4): Attacks all enemies with Dragon's Might, dispelling all buffs, and grants increased Defense to all allies for 2 turns. Increases Combat Readiness of the caster by 50%. Damage dealt increases proportional to the caster's max Health.

Memory Imprint: Release Defense % (B–SSS +5%→+15%). Concentration Health % (B–SSS +7%→+21%).

Preview Stats (6★ awaken Lv.60): Atk 975 / Def 652 / HP 7054 / Speed **106** / Crit **35%** (base 15% + passive 20%) / CDMG 150% / Eff 0% / ER 0% / Dual 3%.

## Defense / offense

5 / 7

## Unsure

- Exact HP damage coefficients for Eradicate / Trample / Genesis
- First-fight opening CD of Genesis
- Exclusive Equipment options (not shown)

## Object

```ts
{
  id: "alencia",
  name: "Alencia",
  short: "Alencia",
  element: "earth",
  class: "warrior",
  tier: "niche",
  rarity: 5,
  roles: ["bruiser", "defense-break", "strip", "injury"],
  tags: ["hp-scaling", "decrease-defense", "injury", "extra-attack", "strip", "aoe", "increase-defense", "cr-push", "soulburn", "mind-eye"],
  effects: ["max-hp-scaled-damage", "trample-extra-attack", "injuries-on-attack", "buff-dispel", "ignore-er"],
  buffs: ["Mind's Eye", "Increase Defense"],
  debuffs: ["Decrease Defense", "Injury"],
  uniqueEffects: [
    {
      name: "Mind's Eye",
      scope: "self-only",
      tooltip: "Undispellable. SoT 75%→100% FE grant 1 turn. While active: up to 10% injuries on attack; enables Trample after Eradicate. Passive also +20% Crit Chance."
    },
    {
      name: "Trample",
      scope: "self-only",
      tooltip: "Extra skill after Eradicate with Mind's Eye: HP-scaled hit + caster CR +15%."
    }
  ],
  kit: "S1 Eradicate (+1 Soul): Def-break 60%→75% FE 1 turn; Soulburn (−10) 100% + ignore ER; dmg ∝ max HP. S2 Noble Blood: +20% Crit; SoT Mind's Eye 75%→100% FE; Eradicate+Mind's Eye → Trample (CR +15%). S3 Genesis (+3 Souls, 5→4 CD): AoE full strip + Increase Defense (+60%) allies 2 turns + caster CR +50%.",
  defense: 5,
  offense: 7,
  baseSpeed: 106,
  verified: true
}
```
