# Aram

Short: Aram

Element: Fire

Class: Soul Weaver

Rarity: 5

Tier: niche

Base Speed: 114

Patch / date used: 2026-09-06 in-game Journal (screenshots)

## Roles

healer, control, speedcap, enabler

## Tags

stun, soulburn, immunity, cr-push, aoe, vigor, exploiting-weak-points

## Effects

increase-cr, ally-cd-reset, ignore-cd-manip

## Buffs

Immunity, Increase Effectiveness, Vigor, Increase Speed, Exploiting Weak Points

## Debuffs

Stun

## Unique effects

### Stun

Enemy. Cannot act for a certain number of turns.

### Immunity

Allies. Cannot be affected by any debuffs or some harmful effects. Coastal Discipline: 3 turns if enemy takes first turn.

### Increase Effectiveness

Allies. Increases Effectiveness by 50%. Coastal Discipline: 3 turns if ally takes first turn.

### Vigor

Allies (undispellable). Increases Attack and Defense by 30%. Granted by Warming Up for 2 turns.

### Increase Speed

Allies. Increases Speed by 30%. Granted by Warming Up for 2 turns.

### Warming Up

Team-wide. Gains 10 Soul and grants Vigor and Increase Speed to all allies for 2 turns. Activated by Coastal Discipline after suffering an attack that targets all allies (ICD = Coastal Discipline skill CD).

### Exploiting Weak Points

Ally. When attacking, increases damage dealt by 20%. After attacking, this effect is dispelled. Granted by Rapid Rescue.

## Kit

S1 Atten-Tion! (+1 Soul): Attacks the enemy by whipping up the sand and has a **25%** chance to inflict stun for 1 turn (enhancements +5% / +5% effect chance → **35%** fully enhanced), before recovering Health of all allies proportional to the caster's max Health. Soulburn (consume 10 Soul): Increases effect chance to 100%.

S2 Coastal Discipline (passive, 4-turn cooldown, enhance −1 → 3): At the start of battle, if an enemy takes the first turn, grants Immunity to all allies for 3 turns; if an ally takes the first turn, grants Increased Effectiveness to all allies for 3 turns. After suffering an attack that targets all allies, activates Warming Up (10 Soul + Vigor + Increase Speed all allies 2 turns).

S3 Rapid Rescue (+3 Souls, 6-turn cooldown, enhance −1 → 5): Fires a rescue line launcher, granting Exploiting Weak Points to an ally except for the caster and resetting skill cooldowns before increasing Combat Readiness by **60%** (enhancements +5%×4 / +5% / +10% / +10% → **100%** fully enhanced). This skill is unaffected by cooldown increase and decrease effects.

Memory Imprint: Release Attack % (B–SSS +5%→+15%). Concentration Health % (B–SSS +7%→+21%).

Preview Stats (6★ awaken Lv.60): Atk 785 / Def 634 / HP 5077 / Speed **114** / Crit 15% / CDMG 150% / Eff 30% / ER 0% / Dual 3%.

## Defense / offense

5 / 2

## Unsure

- First-fight opening CD of Rapid Rescue / Coastal Discipline
- Exact heal coefficient on Atten-Tion! vs max Health

## Object

```ts
{
  id: "aram",
  name: "Aram",
  short: "Aram",
  element: "fire",
  class: "soul weaver",
  tier: "niche",
  rarity: 5,
  roles: ["healer", "control", "speedcap", "enabler"],
  tags: ["stun", "soulburn", "immunity", "cr-push", "aoe", "vigor", "exploiting-weak-points"],
  effects: ["increase-cr", "ally-cd-reset", "ignore-cd-manip"],
  buffs: ["Immunity", "Increase Effectiveness", "Vigor", "Increase Speed", "Exploiting Weak Points"],
  debuffs: ["Stun"],
  uniqueEffects: [
    {
      name: "Warming Up",
      scope: "team-wide",
      tooltip: "Gains 10 Soul. Grants Vigor (Atk/Def +30%, undispellable) and Increase Speed (+30%) to all allies for 2 turns."
    },
    {
      name: "Coastal Discipline",
      scope: "team-wide",
      tooltip: "Enemy first turn → Immunity all 3 turns; ally first turn → Increase Effectiveness (+50%) all 3 turns. After suffering all-ally attack → Warming Up (CD 4→3)."
    },
    {
      name: "Exploiting Weak Points",
      scope: "team-wide",
      tooltip: "When attacking, increases damage dealt by 20%. Dispelled after attacking."
    },
    {
      name: "Vigor",
      scope: "team-wide",
      tooltip: "Undispellable. Increases Attack and Defense by 30%."
    }
  ],
  kit: "S1 Atten-Tion! (+1 Soul): Stun 25%→35% FE + AoE heal ∝ max HP; Soulburn (−10) Stun 100%. S2 Coastal Discipline (passive, 4→3 CD): first-turn Immunity or Eff Up; on suffer AoE → Warming Up (10 Soul + Vigor + Speed Up). S3 Rapid Rescue (+3 Souls, 6→5 CD): Exploiting Weak Points + full CD reset (ally except caster) + CR +60%→100% FE; ignores CD manip.",
  defense: 5,
  offense: 2,
  baseSpeed: 114,
  verified: true
}
```
