# Aki

Short: Aki

Element: Fire

Class: Warrior

Rarity: 5

Tier: niche

Base Speed: 112

Patch / date used: 2026-09-06 in-game Journal (screenshots); reflects post–2026-07-16 kit

## Roles

dps, strip, bruiser

## Tags

burn, strip, soulburn, defbreak, extra-turn, ignore-er, detonate

## Effects

buff-dispel, extra-turn, damage-received-limit, ignore-damage-sharing, ignore-er, detonate

## Buffs

none

## Debuffs

Burn, Decrease Defense

## Unique effects

### Final Radiance

Self-only. Increases Attack by **35%** (enhancements +2/+3/+3/+3/+4% → **50%** fully enhanced). Cannot receive recover Health effects and damage sharing effects. When attacked, damage suffered in one attack does not exceed 51% of max Health. When using Soulburn, if Health exceeds 51%, consumes 51% Health instead of Soul, and grants an extra turn.

### Burn

Enemy. At the start of the turn, suffers huge damage proportional to the caster's Attack.

### Detonate

Instantly activates designated debuffs inflicted on the enemy. Poison, Bleed, Burn, Venom, and Erosion damages are proportional to the number of turns and quantity. Bomb damage is unaffected by the number of turns.

### Decrease Defense

Enemy. Decreases Defense by 70%.

### Extra Turn

Grants an extra turn. Via Final Radiance when Soulburn is used (HP>51% path).

## Kit

S1 Baptism of Fire (+1 Soul): Attacks the enemy with a blaze, with a **75%** chance to inflict burn for 1 turn (enhancements +10% / +15% effect chance → **100%** fully enhanced). At the end of the turn, detonates burn effects inflicted on the target. Soulburn (consume **20** Soul): Extends duration of burn by 3 turns, and ignores Effect Resistance. This attack does not trigger a Dual Attack.

S2 Final Radiance (passive): See unique effects.

S3 Karmic Flame (+2 Souls, **4**-turn cooldown, enhance −1 → **3**): Attacks the enemy, dispelling all buffs before inflicting decreased Defense for 2 turns, and a **75%** chance each to inflict two burn effects for 2 turns (enhancements +10% / +15% effect chance → **100%** fully enhanced). At the end of the turn, detonates burn effects inflicted on the target. Soulburn (consume **20** Soul): Ignores Effect Resistance.

Memory Imprint: Release Health % (B–SSS +4%→+12%). Concentration Effect Resistance (B–SSS +9%→+27%).

Preview Stats (6★ awaken Lv.60): Atk 1304 / Def 668 / HP 5663 / Speed **112** / Crit 15% / CDMG 150% / Eff 0% / ER 30% / Dual 3%.

## Defense / offense

6 / 8

## Unsure

- First-fight opening CD of Karmic Flame
- Exact detonation / skill damage multipliers after 2026-07-16 notes

## Object

```ts
{
  id: "aki",
  name: "Aki",
  short: "Aki",
  element: "fire",
  class: "warrior",
  tier: "niche",
  rarity: 5,
  roles: ["dps", "strip", "bruiser"],
  tags: ["burn", "strip", "soulburn", "defbreak", "extra-turn", "ignore-er", "detonate"],
  effects: ["buff-dispel", "extra-turn", "damage-received-limit", "ignore-damage-sharing", "ignore-er", "detonate"],
  buffs: [],
  debuffs: ["Burn", "Decrease Defense"],
  uniqueEffects: [
    {
      name: "Final Radiance",
      scope: "self-only",
      tooltip: "Atk +35% (→50% FE). No heal/share. Damage per hit capped at 51% max HP. Soulburn while HP>51%: spend 51% HP instead of Soul + Extra Turn."
    },
    {
      name: "Burn detonation",
      scope: "self-only",
      tooltip: "S1/S3: at end of turn, detonates burn effects on the target."
    }
  ],
  kit: "S1 Baptism of Fire (+1 Soul): Burn 75%→100% FE 1 turn + EOT detonate; Soulburn (−20) Burn +3 turns, ignore ER, no Dual Attack. S2 Final Radiance: Atk +35%→50% FE; no heal/share; 51% HP dmg cap; Soulburn HP cost + Extra Turn. S3 Karmic Flame (+2 Souls, 4→3 CD): full strip; Def-break 2 turns; two Burns 75%→100% FE 2 turns; EOT detonate; Soulburn (−20) ignore ER.",
  defense: 6,
  offense: 8,
  baseSpeed: 112,
  verified: true
}
```
