# Aramintha

Short: Aramintha

Element: Fire

Class: Mage

Rarity: 5

Tier: niche

Base Speed: 106

Patch / date used: 2026-09-06 in-game Journal (screenshots)

## Roles

cleave, strip, control, dps

## Tags

aoe, strip, unhealable, stun, soulburn, cr-push, barrier, ignore-er, burn

## Effects

buff-dispel, increase-cr

## Buffs

Increase Attack, Barrier

## Debuffs

Burn, Unhealable, Stun

## Unique effects

### Catalyst CR

Self-only. For each Unhealable inflicted, increases Combat Readiness of the caster by 30%.

### Scarlet Tear — Ignite detonation (Exclusive Equipment option)

Self-only. After using Ignite, at the end of the turn, detonates burn effects inflicted on the target. (Optional EE; not verified in these Journal screenshots.)

## Kit

S1 Ignite (+1 Soul): Attacks the enemy with an explosion of flames, with a **35%** chance to burn for **2 turns** (enhancements +5% / +10% effect chance → **50%** fully enhanced). No innate detonation on the skill card (EE option Scarlet Tear not shown in these screenshots).

S2 Catalyst (+2 Souls, 5-turn cooldown, enhance −1 → 4): Attacks all enemies with a catalytic explosion, dispelling two buffs and making them Unhealable for 2 turns, before increasing Attack of all allies for 2 turns (Increase Attack = +50%). For each Unhealable inflicted, increases Combat Readiness of the caster by 30%.

S3 Fire Pillar (+2 Souls, 5-turn cooldown, enhance −1 → 4): Attacks all enemies with a massive fire pillar, with an **80%** chance each to inflict two burn effects for 2 turns and a **50%** chance to inflict stun for 1 turn (enhancements +10% / +10% effect chance → burns **100%** / stun **70%** fully enhanced). Grants a barrier (proportional to the caster's Attack) to the caster for 2 turns. Soulburn (consume 20 Soul): Ignores Effect Resistance.

Memory Imprint: Release Attack % (B–SSS +4%→+12%). Concentration Effectiveness % (B–SSS +9%→+27%).

Preview Stats (6★ awaken Lv.60): Atk 1197 / Def 683 / HP 4572 / Speed **106** / Crit 15% / CDMG 150% / Eff 30% / ER 0% / Dual 3%.

## Defense / offense

3 / 7

## Unsure

- First-fight (opening) cooldowns of Catalyst and Fire Pillar (not shown on Journal skill cards)
- Exact Exclusive Equipment lines (Scarlet Tear / other options) — not in these screenshots

## Object

```ts
{
  id: "aramintha",
  name: "Aramintha",
  short: "Aramintha",
  element: "fire",
  class: "mage",
  tier: "niche",
  rarity: 5,
  roles: ["cleave", "strip", "control", "dps"],
  tags: ["aoe", "strip", "unhealable", "stun", "soulburn", "cr-push", "barrier", "ignore-er", "burn"],
  effects: ["buff-dispel", "increase-cr"],
  buffs: ["Increase Attack", "Barrier"],
  debuffs: ["Burn", "Unhealable", "Stun"],
  uniqueEffects: [
    {
      name: "Catalyst CR",
      scope: "self-only",
      tooltip: "For each Unhealable inflicted, increases Combat Readiness of the caster by 30%."
    },
    {
      name: "Scarlet Tear Ignite detonation",
      scope: "self-only",
      tooltip: "After using Ignite, at the end of the turn, detonates burn effects inflicted on the target. (Exclusive Equipment option; not verified in Journal screenshots.)"
    }
  ],
  kit: "S1 Ignite (+1 Soul): Burn 35%→50% FE for 2 turns. S2 Catalyst (+2 Souls, 5→4 CD): AoE dispel 2 + Unhealable 2 turns + Increase Attack allies 2 turns (+50%); +30% CR per Unhealable. S3 Fire Pillar (+2 Souls, 5→4 CD): AoE two Burns 80%→100% FE + Stun 50%→70% FE + self Barrier (∝ Atk); Soulburn (−20) ignore ER. Speed 106.",
  defense: 3,
  offense: 7,
  baseSpeed: 106,
  verified: true
}
```
