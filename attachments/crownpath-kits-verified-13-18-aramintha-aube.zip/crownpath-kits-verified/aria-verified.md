# Aria

Short: Aria

Element: Ice

Class: Mage

Rarity: 5

Tier: niche

Base Speed: 115

Patch / date used: 2026-09-06 in-game Journal (screenshots)

## Roles

counter, strip, tank-bruiser, stealth-support, cr-cut

## Tags

dual-hit, decrease-hit-chance, focus, strip, cr-cut, counterattack, stealth, barrier, defense-scaling, soulburn

## Effects

decrease-hit-chance, focus-consume-aoe, buff-dispel, decrease-cr, counterattack-stance, stealth-allies, defense-scaled-damage

## Buffs

Increase Defense, Counterattack, Stealth, Barrier

## Debuffs

Decrease Hit Chance

## Unique effects

### Focus / Dark Shadow Phantom

Self → enemies (AoE). Passive Guide of Darkness: increases Critical Hit Chance by **20%** (skill enhancements +1%×4 / +2%×3 → **+10%**, fully enhanced **30%** Crit Chance from this passive). After using a skill, when Focus is full, activates Dark Shadow Phantom: consumes **5 Focus**, attacks all enemies, dispels two buffs, decreases Combat Readiness by 30%; damage ∝ Defense.

### The Umbral Hour

Self + allies except caster. Grants Increased Defense (+60%) and Counterattack to the caster for 2 turns. Grants Stealth and a Barrier (proportional to the caster's Defense) to all allies except the caster for 2 turns.

## Kit

S1 Shadow Call (Acquire 1 Focus, +1 Soul): Attacks two enemies with shadows, with a **40%** chance to Decrease Hit Chance for 1 turn (enhancements +5% / +5% effect chance → **50%** fully enhanced). When it is not the caster's turn, increases effect chance by 20% (FE off-turn **70%**). Damage dealt increases proportional to the caster's Defense. Soulburn (consume 20 Soul): grants an extra turn.

S2 Guide of Darkness (passive): Increases Critical Hit Chance by 20% (→ **30%** fully enhanced). After using a skill, when Focus is full, activates Dark Shadow Phantom (consume 5 Focus: AoE attack, dispel two buffs, CR −30%; damage ∝ Defense).

S3 The Umbral Hour (Acquire 3 Focus, +3 Souls, 5-turn cooldown, enhance −1 → 4): Using the power of shadows, grants Increased Defense and Counterattack to the caster for 2 turns. Grants Stealth and a Barrier (proportional to the caster's Defense) to all allies except for the caster for 2 turns.

Memory Imprint: Release Defense % (B–SSS +5%→+15%). Concentration Defense % (B–SSS +7%→+21%).

Preview Stats (6★ awaken Lv.60): Atk 1039 / Def 673 / HP 5299 / Speed **115** / Crit 35% / CDMG 150% / Eff 18% / ER 18% / Dual 3%.

## Defense / offense

7 / 6

## Unsure

- Exact Barrier coefficient vs Defense on The Umbral Hour
- First-fight (opening) cooldown of The Umbral Hour
- Whether counterattacks grant Focus the same way as skill uses (Journal only shows S1 +1 Focus / S3 +3 Focus on skill cards)

## Object

```ts
{
  id: "aria",
  name: "Aria",
  short: "Aria",
  element: "ice",
  class: "mage",
  tier: "niche",
  rarity: 5,
  roles: ["counter", "strip", "tank-bruiser", "stealth-support", "cr-cut"],
  tags: ["dual-hit", "decrease-hit-chance", "focus", "strip", "cr-cut", "counterattack", "stealth", "barrier", "defense-scaling", "soulburn"],
  effects: ["decrease-hit-chance", "focus-consume-aoe", "buff-dispel", "decrease-cr", "counterattack-stance", "stealth-allies", "defense-scaled-damage"],
  buffs: ["Increase Defense", "Counterattack", "Stealth", "Barrier"],
  debuffs: ["Decrease Hit Chance"],
  uniqueEffects: [
    {
      name: "Dark Shadow Phantom",
      scope: "targets",
      tooltip: "On full Focus after a skill: consume 5 Focus; AoE attack, dispel 2 buffs, CR −30%; damage ∝ Defense."
    },
    {
      name: "The Umbral Hour",
      scope: "allies",
      tooltip: "Self Increase Defense (+60%) + Counterattack 2 turns; Stealth + Barrier (∝ Def) on allies except caster 2 turns."
    }
  ],
  kit: "S1 Shadow Call (+1 Focus, +1 Soul): hit two enemies, Decrease Hit Chance 40%→50% FE (off-turn +20%); Def-scaled; Soulburn (−20) extra turn. S2 Guide of Darkness: Crit +20%→30% FE; full Focus → Dark Shadow Phantom (consume 5: strip 2 + CR −30%). S3 The Umbral Hour (+3 Focus, +3 Souls, 5→4 CD): self Def Up + Counter; Stealth + Barrier allies. Speed 115.",
  defense: 7,
  offense: 6,
  baseSpeed: 115,
  verified: true
}
```
