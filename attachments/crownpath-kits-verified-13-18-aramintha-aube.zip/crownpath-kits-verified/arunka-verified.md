# Arunka

Short: Arunka

Element: Earth

Class: Warrior

Rarity: 5

Tier: niche

Base Speed: 102

Patch / date used: 2026-09-06 in-game Journal (screenshots)

## Roles

dps, barrier-breaker, bleed, sustain

## Tags

bleed, extra-attack, no-crit, barrier-bonus, defense-penetration, extinction, heal, soulburn, cr-push

## Effects

cannot-crit, cannot-heavy-blow, barrier-end-turn-cr, expose-heal, barrier-bonus-damage

## Buffs

none

## Debuffs

Bleed

## Unique effects

### Wild Instinct

Self-only. Increases Attack by 30%. When attacking, cannot trigger a critical hit or a heavy blow. At the end of an enemy's turn, when the target is granted a Barrier, increases Combat Readiness of the caster by **5%** (skill enhancements +1%×5 → **10%** fully enhanced).

### Expose (extra attack)

Targets (single). From Dagger Throw: attacks the target and recovers Health proportional to Attack. Can only be activated once per turn during the caster's turn. Soulburn on S1: 100% chance to activate Expose.

### A Thrashing In The Prairie

Targets (single). Penetrates Defense by 70%; when the target is granted a Barrier, increases damage dealt. When the enemy is defeated, inflicts Extinction and resets this skill's cooldown.

## Kit

S1 Dagger Throw (+1 Soul): Attacks the enemy by throwing daggers and has a 50% chance each to inflict two Bleeding effects for 2 turns. A successful attack will have a 50% chance to activate Expose as an extra attack (Expose once per turn during the caster's turn: attack + heal ∝ Attack). Soulburn (consume 10 Soul): 100% chance to activate Expose.

S2 Wild Instinct (passive): Increases Attack by 30%. When attacking, cannot trigger a critical hit or a heavy blow. At the end of an enemy's turn, when the target is granted a Barrier, increases Combat Readiness of the caster by **5%→10%** fully enhanced.

S3 A Thrashing In The Prairie (+3 Souls, 5-turn cooldown, enhance −1 → 4): Attacks the enemy by quickly running up to them. When the enemy is defeated, inflicts Extinction and resets the cooldown of this skill. Penetrates the target's Defense by 70%, and when the target is granted a Barrier, increases damage dealt.

Memory Imprint: Release Health % (B–SSS +4%→+12%). Concentration Attack % (B–SSS +7%→+21%).

Preview Stats (6★ awaken Lv.60): Atk 1570 / Def 616 / HP 6488 / Speed **102** / Crit 15% / CDMG 150% / Eff 0% / ER 0% / Dual 3%.

## Defense / offense

4 / 8

## Unsure

- Exact increased-damage % vs Barrier on S3 (Journal only says "increases damage dealt")
- Exact Expose heal coefficient vs Attack
- First-fight (opening) cooldown of S3

## Object

```ts
{
  id: "arunka",
  name: "Arunka",
  short: "Arunka",
  element: "earth",
  class: "warrior",
  tier: "niche",
  rarity: 5,
  roles: ["dps", "barrier-breaker", "bleed", "sustain"],
  tags: ["bleed", "extra-attack", "no-crit", "barrier-bonus", "defense-penetration", "extinction", "heal", "soulburn", "cr-push"],
  effects: ["cannot-crit", "cannot-heavy-blow", "barrier-end-turn-cr", "expose-heal", "barrier-bonus-damage"],
  buffs: [],
  debuffs: ["Bleed"],
  uniqueEffects: [
    {
      name: "Wild Instinct",
      scope: "self",
      tooltip: "+30% Attack; cannot crit or heavy blow. Enemy end-turn with Barrier → caster CR +5%→10% FE."
    },
    {
      name: "Expose",
      scope: "targets",
      tooltip: "Extra attack from S1: attack + heal ∝ Attack; once per caster turn. Soulburn (−10) guarantees."
    }
  ],
  kit: "S1 Dagger Throw (+1): 2× Bleed 50% each; 50% Expose (heal ∝ Atk). Soulburn (−10): 100% Expose. S2 Wild Instinct: +30% Atk, no crit/heavy blow; barrier end-turn CR 5%→10% FE. S3 Thrashing (+3, 5→4): 70% pen + barrier bonus dmg; kill → Extinction + CD reset. Speed 102.",
  defense: 4,
  offense: 8,
  baseSpeed: 102,
  verified: true
}
```
