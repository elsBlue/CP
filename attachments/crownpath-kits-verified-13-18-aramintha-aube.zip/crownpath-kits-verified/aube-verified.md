# Aube

Short: Aube

Element: Ice

Class: Ranger

Rarity: 5

Tier: niche

Base Speed: 120

Patch / date used: 2026-09-06 in-game Journal (screenshots)

## Roles

opener, control, cascade, skill-nullifier, cr-cut

## Tags

single-target, aoe-control, immobilize, restrict, cascade, skill-nullifier, concealment, strip, extra-turn, soulburn, cr-cut

## Effects

decrease-cr, cascade-allies, skill-nullifier, extra-turn, immobilize, restrict, concealment-untargetable, buff-dispel, ignore-effect-resistance-soulburn

## Buffs

Cascade, Skill Nullifier, Concealment

## Debuffs

Immobilize, Restrict

## Unique effects

### Cascade

Allies (undispellable). After attacking, inflicts 4,000 additional damage on the target. Dispelled after attacking. Granted by Film Fiesta.

### Immobilize

Enemy. Cannot receive Combat Readiness increase effects provided by the Speed stat. Dispelled at the start of someone's fourth turn.

### Restrict

Enemy. Cannot receive Combat Readiness increase effects other than that provided by the Speed stat.

### Concealment

Self (undispellable). Remains throughout the battle. When another ally is present, prevents enemies from selecting the bearer as a skill target.

## Kit

S1 Coral Swell (+1 Soul): Attacks the enemy with coral magic and decreases Combat Readiness by **15%** (enhancements +2% / +3% → **20%** fully enhanced).

S2 Film Fiesta (+1 Soul, 3-turn cooldown): Releases the moment engraved in the film, with a **70%** chance to grant Cascade to all allies (enhancements +5%×4 / +10% → **100%** fully enhanced). Grants Skill Nullifier once and an Extra Turn to the caster.

S3 Eternal Moment (+3 Souls, 7-turn cooldown, enhance −1 → 6): Fixes all enemies in a frame, dispelling two buffs before a **70%** chance each to inflict Immobilize and Restrict for **2 turns** (enhancements +5% / +5% / +10% / +10% effect chance → **100%** fully enhanced). Concealment will remain throughout the battle. Soulburn (consume **20** Soul): Ignores Effect Resistance.

Memory Imprint: Release Attack % (B–SSS +4%→+12%). Concentration Effectiveness % (B–SSS +9%→+27%).

Preview Stats (6★ awaken Lv.60): Atk 993 / Def 611 / HP 6002 / Speed **120** / Crit 15% / CDMG 150% / Eff 0% / ER 0% / Dual 3%.

## Defense / offense

4 / 5

## Unsure

- Concealment vs AoE / provocations / bombs (Journal only covers single-target selection)
- First-fight (opening) cooldown of Eternal Moment

## Object

```ts
{
  id: "aube",
  name: "Aube",
  short: "Aube",
  element: "ice",
  class: "ranger",
  tier: "niche",
  rarity: 5,
  roles: ["opener", "control", "cascade", "skill-nullifier", "cr-cut"],
  tags: ["single-target", "aoe-control", "immobilize", "restrict", "cascade", "skill-nullifier", "concealment", "strip", "extra-turn", "soulburn", "cr-cut"],
  effects: ["decrease-cr", "cascade-allies", "skill-nullifier", "extra-turn", "immobilize", "restrict", "concealment-untargetable", "buff-dispel", "ignore-effect-resistance-soulburn"],
  buffs: ["Cascade", "Skill Nullifier", "Concealment"],
  debuffs: ["Immobilize", "Restrict"],
  uniqueEffects: [
    {
      name: "Cascade",
      scope: "allies",
      tooltip: "Undispellable. After attacking, inflicts 4,000 additional damage on the target; dispelled after attacking."
    },
    {
      name: "Immobilize",
      scope: "targets",
      tooltip: "Cannot receive CR increase from Speed. Dispelled at the start of someone's fourth turn."
    },
    {
      name: "Restrict",
      scope: "targets",
      tooltip: "Cannot receive CR increase other than from Speed."
    },
    {
      name: "Concealment",
      scope: "self-only",
      tooltip: "Throughout battle. When another ally is present, prevents enemies from selecting the bearer as a skill target."
    }
  ],
  kit: "S1 Coral Swell (+1 Soul): CR −15%→20% FE. S2 Film Fiesta (+1 Soul, 3 CD): Cascade all allies 70%→100% FE (+4k add dmg after attack); self Skill Nullifier + Extra Turn. S3 Eternal Moment (+3 Souls, 7→6 CD): AoE strip 2 + Immobilize/Restrict 70%→100% FE for 2 turns; Concealment for battle; Soulburn (−20) Ignore ER. Speed 120.",
  defense: 4,
  offense: 5,
  baseSpeed: 120,
  verified: true
}
```
