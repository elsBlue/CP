# Aubade Ludwig

Short: Aubade Ludwig

Element: Ice

Class: Ranger

Rarity: 5

Tier: niche

Base Speed: 115

Patch / date used: 2026-09-06 in-game Journal (screenshots)

## Roles

control, soul-spender, strip, barrier, bruiser-support

## Tags

single-target, aoe, dawn, soul-consume, block, silence, stun, strip, barrier, cr-push, soulburn, max-health-scaling

## Effects

dawn-soul-and-stun, light-of-condemnation, soul-scaled-additional-damage, buff-dispel, block, silence, barrier-max-hp, ally-turn-cr-when-souls

## Buffs

Dawn, Barrier

## Debuffs

Block, Silence, Stun

## Unique effects

### Dawn

Self (undispellable). Granted by White Night for 3 turns. Increases the amount of Soul acquired by 100%. After attacking, has a 25% chance to inflict Stun on the target for 1 turn.

### Light of Condemnation

Targets (AoE). When the caster is granted Dawn, Moonlight activates this as an extra attack once per turn during the caster's turn. Acquire 5 Soul (skill header). Attacks all enemies and consumes all Soul regardless of whether the attack hits, inflicting 1,000 additional damage (additional damage increases proportional to consumed Soul, up to 25,000).

### Night Greeting the Dawn

Self. Passive: increases Defense by 30%. At the end of an ally's turn, if the team has 10 or more Souls, increases Combat Readiness of the caster by **15%** (skill enhancements +1%×5 → **20%** fully enhanced).

## Kit

S1 Moonlight (+1 Soul): Attacks the enemy with moonlight. When the caster is granted Dawn, activates Light of Condemnation as an extra attack (once per turn during the caster's turn): attacks all enemies, consumes all Soul whether hit or miss, 1,000 additional damage up to 25,000 ∝ Soul consumed.

S2 Night Greeting the Dawn (passive): Increases Defense by 30%. At the end of an ally's turn, if Soul ≥ 10, increases Combat Readiness of the caster by **15%→20%** fully enhanced.

S3 White Night (+3 Souls, 5-turn cooldown, enhance −1 → 4): Dispels two buffs from all enemies, with a **60%** chance each to inflict Block for 2 turns and Silence for 1 turn (enhancements +5% / +5% / +5% / +10% effect chance → **85%** fully enhanced). Grants Dawn and a Barrier (proportional to max Health) to the caster for 3 turns. Soulburn (consume 10 Soul): increases the strength of the Barrier.

Memory Imprint: Release Effectiveness % (B–SSS +5%→+15%). Concentration Effectiveness % (B–SSS +9%→+27%).

Preview Stats (6★ awaken Lv.60): Atk 1003 / Def 760 / HP 5704 / Speed **115** / Crit 15% / CDMG 150% / Eff 30% / ER 0% / Dual 3%.

## Defense / offense

5 / 6

## Unsure

- Exact Barrier coefficient vs max Health
- Light of Condemnation “Acquire 5 Soul” timing relative to consuming all Soul
- First-fight (opening) cooldown of White Night
- Whether Dawn's after-attack Stun can proc on Light of Condemnation hits

## Object

```ts
{
  id: "aubade-ludwig",
  name: "Aubade Ludwig",
  short: "Aubade Ludwig",
  element: "ice",
  class: "ranger",
  tier: "niche",
  rarity: 5,
  roles: ["control", "soul-spender", "strip", "barrier", "bruiser-support"],
  tags: ["single-target", "aoe", "dawn", "soul-consume", "block", "silence", "stun", "strip", "barrier", "cr-push", "soulburn", "max-health-scaling"],
  effects: ["dawn-soul-and-stun", "light-of-condemnation", "soul-scaled-additional-damage", "buff-dispel", "block", "silence", "barrier-max-hp", "ally-turn-cr-when-souls"],
  buffs: ["Dawn", "Barrier"],
  debuffs: ["Block", "Silence", "Stun"],
  uniqueEffects: [
    {
      name: "Dawn",
      scope: "self-only",
      tooltip: "Undispellable. Soul acquisition +100%; after attacking, 25% chance Stun 1 turn on the target."
    },
    {
      name: "Light of Condemnation",
      scope: "targets",
      tooltip: "With Dawn, once per caster turn: AoE, consume all Soul, 1,000–25,000 additional damage ∝ Soul spent."
    }
  ],
  kit: "S1 Moonlight (+1 Soul): if Dawn → Light of Condemnation (AoE Soul consume + 1k–25k add dmg). S2 Night Greeting the Dawn: Def +30%; ally end-turn if Soul≥10 → CR 15%→20% FE. S3 White Night (+3 Souls, 5→4 CD): AoE strip 2 + Block/Silence 60%→85% FE; Dawn + Barrier ∝ max HP 3 turns; Soulburn (−10) stronger barrier. Speed 115.",
  defense: 5,
  offense: 6,
  baseSpeed: 115,
  verified: true
}
```
