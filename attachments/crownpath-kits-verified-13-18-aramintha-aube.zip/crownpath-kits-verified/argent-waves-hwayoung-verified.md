# Argent Waves Hwayoung

Short: AW Hwayoung

Element: Ice

Class: Thief

Rarity: 5

Tier: niche

Base Speed: 116

Patch / date used: 2026-09-06 in-game Journal (screenshots)

## Roles

dps, strip, follow-up, cleave, vigor

## Tags

single-target, aoe, strip, penetration, vigor, extra-turn, cr-push, soulburn, non-attack-trigger

## Effects

buff-dispel, defense-penetration, vigor-extra-turn, swallow-kick-on-ally-non-attack, back-row-cr-push

## Buffs

Vigor, Increase Attack

## Debuffs

(none)

## Unique effects

### Advent of the Sura / Swallow Kick

Self follow-up (3-turn cooldown). After an ally uses a non-attack skill, activates Swallow Kick on the enemy with the highest Defense. Swallow Kick: after granting Increased Attack to the caster for 2 turns, attacks the enemy by leaping forward, increases Combat Readiness of the caster by 20%, and penetrates the target's Defense by 50%. When the caster is granted Vigor, grants an extra turn.

### Argent Flash vigor + back-row CR

Self + back-row ally. AoE attack; increases Combat Readiness of the ally in the back row by 50%; grants Vigor to the caster for 2 turns. Soulburn (consume 10 Soul): increases damage dealt.

## Kit

S1 Lightning Kicks (+1 Soul): Attacks the enemy with kicks and dispels one buff.

S2 Advent of the Sura (passive, **3-turn cooldown**): After an ally uses a non-attack skill, activates Swallow Kick on the enemy with the highest Defense. Swallow Kick: after granting **Increased Attack** to the caster for 2 turns (+50% Attack), attacks the enemy, increases Combat Readiness of the caster by 20%, and penetrates Defense by 50%. When the caster is granted Vigor, grants an extra turn.

S3 Argent Flash (+3 Souls, 5-turn cooldown, enhance −1 → 4): Attacks all enemies with a water scooter, and increases Combat Readiness of the ally in the back row by 50%. Grants Vigor to the caster for 2 turns (undispellable; Attack and Defense +30%). Soulburn (consume 10 Soul): increases damage dealt.

Memory Imprint: Release Effectiveness % (B–SSS +6%→+18%). Concentration Critical Hit Chance % (B–SSS +6%→+18%).

Preview Stats (6★ awaken Lv.60): Atk 1283 / Def 522 / HP 5138 / Speed **116** / Crit 23% / CDMG 150% / Eff 0% / ER 0% / Dual 3%.

## Defense / offense

2 / 8

## Unsure

- First-fight (opening) cooldown of Argent Flash (not shown on Journal skill card)
- Exact back-row targeting rules when formation/order changes mid-fight

## Object

```ts
{
  id: "argent-waves-hwayoung",
  name: "Argent Waves Hwayoung",
  short: "AW Hwayoung",
  element: "ice",
  class: "thief",
  tier: "niche",
  rarity: 5,
  roles: ["dps", "strip", "follow-up", "cleave", "vigor"],
  tags: ["single-target", "aoe", "strip", "penetration", "vigor", "extra-turn", "cr-push", "soulburn", "non-attack-trigger"],
  effects: ["buff-dispel", "defense-penetration", "vigor-extra-turn", "swallow-kick-on-ally-non-attack", "back-row-cr-push"],
  buffs: ["Vigor", "Increase Attack"],
  debuffs: [],
  uniqueEffects: [
    {
      name: "Swallow Kick",
      scope: "self",
      tooltip: "After ally non-attack skill (S2 CD 3): attack highest-Defense enemy; grant Increase Attack 2 turns first; 50% Def pen; CR +20%; with Vigor, extra turn."
    },
    {
      name: "Argent Flash vigor + back-row CR",
      scope: "self",
      tooltip: "AoE; back-row ally CR +50%; Vigor 2 turns on caster; Soulburn (−10) more damage."
    }
  ],
  kit: "S1 Lightning Kicks (+1 Soul): dispel 1 buff. S2 Advent of the Sura (passive, CD 3): ally non-attack → Swallow Kick (Increase Attack 2 turns, 50% pen, CR +20%; Vigor → extra turn). S3 Argent Flash (+3 Souls, 5→4 CD): AoE + back-row CR +50% + Vigor 2 turns; Soulburn (−10) more damage. Speed 116.",
  defense: 2,
  offense: 8,
  baseSpeed: 116,
  verified: true
}
```
